# Exhale

An Expo + TypeScript first-pass prototype for calm, structured peer-support sessions. This build deliberately uses local mocked state; it is a UI/UX prototype, not a production safety system.

## Run it

```bash
npm install
npm start
```

Then open it in Expo Go, an iOS simulator, or an Android emulator.

## Included

- Adult-only onboarding: age confirmation, age bracket, topics, matching region/language, safety agreement, and a practice check-in.
- Today, Journal, Resources, and Settings tabs, with local interactions for mood, journal entries, matching preferences, a breathing moment, and a finite resource list.
- Session flow: waiting room, guided chat, local keyword-based safety card, mutual history-consent states, private reflection, optional weekly-continuation request, and a deliberate close.
- Calm design tokens in `src/theme.ts` for the warm background, muted accents, soft radii, typography, and diffused shadow.

## Deliberately not live yet

- Accounts, real matches, realtime chat, notifications, voice, and persisted data.
- Server-side crisis classification and human moderator escalation. The in-session keyword trigger is a clearly labelled prototype interaction only.
- The Postgres consent trigger and Supabase Edge Functions called for by the product spec.

Before any real-world use, implement the server-enforced mutual-history gate, server-side crisis routing, verified locale-specific resources, moderation operations, privacy/security review, and a clinical/safety review.
