import { StatusBar } from 'expo-status-bar';
import { useEffect, useRef, useState } from 'react';
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

import { ageBrackets, initialJournal, moodWeeks, resources, starterMessages, topicOptions } from './src/data';
import { colors, radius, shadow, type } from './src/theme';

type AppStage = 'onboarding' | 'home' | 'waiting' | 'session' | 'reflection' | 'closed';
type Tab = 'Today' | 'Journal' | 'Resources' | 'Settings';
type ChatMessage = { id: string; sender: 'You' | 'Sol'; text: string; time: string };

const moodOptions = [
  { label: 'Heavy', mark: '●', color: '#D8AAA1' },
  { label: 'Low', mark: '●', color: '#D9C4A5' },
  { label: 'Steady', mark: '●', color: '#B9C5A9' },
  { label: 'Light', mark: '●', color: '#9EBBBA' },
  { label: 'Good', mark: '●', color: '#9EABC7' },
];

const crisisWords = ['suicide', 'kill myself', 'hurt myself', "can't go on", 'end my life'];

function PrimaryButton({
  label,
  onPress,
  quiet = false,
  disabled = false,
}: {
  label: string;
  onPress: () => void;
  quiet?: boolean;
  disabled?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        quiet ? styles.buttonQuiet : styles.buttonPrimary,
        disabled && styles.buttonDisabled,
        pressed && !disabled && styles.buttonPressed,
      ]}
    >
      <Text style={[styles.buttonText, quiet && styles.buttonQuietText, disabled && styles.buttonDisabledText]}>{label}</Text>
    </Pressable>
  );
}

function SmallAction({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.smallAction, pressed && styles.buttonPressed]}>
      <Text style={styles.smallActionText}>{label}</Text>
    </Pressable>
  );
}

function AppMark({ small = false }: { small?: boolean }) {
  return (
    <View style={[styles.mark, small && styles.markSmall]}>
      <View style={[styles.markRing, small && styles.markRingSmall]} />
      <View style={[styles.markCore, small && styles.markCoreSmall]} />
    </View>
  );
}

function ProgressDots({ step }: { step: number }) {
  return (
    <View style={styles.progressDots}>
      {[0, 1, 2, 3, 4, 5].map((dot) => (
        <View key={dot} style={[styles.progressDot, dot <= step && styles.progressDotActive]} />
      ))}
    </View>
  );
}

function Onboarding({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [ageBracket, setAgeBracket] = useState('25–34');
  const [topics, setTopics] = useState(new Set<string>(['Anxiety', 'Work / study stress']));
  const [regionMode, setRegionMode] = useState<'near' | 'anywhere' | 'specific'>('anywhere');
  const [region, setRegion] = useState('India');
  const [language, setLanguage] = useState('English');
  const [safetyAgreed, setSafetyAgreed] = useState(false);
  const [practiceReply, setPracticeReply] = useState('');
  const [practiceSent, setPracticeSent] = useState(false);

  const next = () => setStep((current) => Math.min(current + 1, 6));
  const back = () => setStep((current) => Math.max(current - 1, 0));
  const toggleTopic = (topic: string) => {
    setTopics((current) => {
      const copy = new Set(current);
      copy.has(topic) ? copy.delete(topic) : copy.add(topic);
      return copy;
    });
  };

  const content = () => {
    if (step === 0) {
      return (
        <View style={styles.welcomeScreen}>
          <View style={styles.welcomeTop}>
            <AppMark />
            <Text style={styles.wordmark}>exhale</Text>
          </View>
          <View>
            <Text style={styles.eyebrow}>A little room to breathe</Text>
            <Text style={styles.welcomeTitle}>You don’t have to carry it alone.</Text>
            <Text style={styles.welcomeCopy}>
              Exhale makes space for occasional, thoughtful conversations with someone who understands.
            </Text>
          </View>
          <View style={styles.welcomeFooter}>
            <PrimaryButton label="Begin gently" onPress={next} />
            <Text style={styles.finePrint}>Peer support for adults · not a replacement for therapy</Text>
          </View>
        </View>
      );
    }

    if (step === 1) {
      return (
        <OnboardingFrame step={step} onBack={back} title="A small, important check." subtitle="Exhale is for adults connecting with other adults.">
          <View style={styles.illustrationCard}>
            <Text style={styles.illustrationIcon}>18+</Text>
            <Text style={styles.illustrationTitle}>A space for adults</Text>
            <Text style={styles.illustrationCopy}>We never ask for your exact date of birth.</Text>
          </View>
          <Pressable onPress={() => setAgeConfirmed(!ageConfirmed)} style={[styles.checkRow, ageConfirmed && styles.checkRowActive]}>
            <View style={[styles.checkbox, ageConfirmed && styles.checkboxActive]}>{ageConfirmed && <Text style={styles.checkMark}>✓</Text>}</View>
            <Text style={styles.checkText}>I confirm that I’m 18 or older.</Text>
          </Pressable>
          <PrimaryButton label="Continue" onPress={next} disabled={!ageConfirmed} />
        </OnboardingFrame>
      );
    }

    if (step === 2) {
      return (
        <OnboardingFrame step={step} onBack={back} title="Which chapter are you in?" subtitle="A broad range helps us match with care. This is never shown on your profile.">
          <View style={styles.optionStack}>
            {ageBrackets.map((item) => (
              <ChoiceRow key={item} label={item} selected={ageBracket === item} onPress={() => setAgeBracket(item)} />
            ))}
          </View>
          <PrimaryButton label="Continue" onPress={next} />
        </OnboardingFrame>
      );
    }

    if (step === 3) {
      return (
        <OnboardingFrame step={step} onBack={back} title="What would feel helpful to talk about?" subtitle="Choose as many as you like. You can change these anytime.">
          <View style={styles.chipWrap}>
            {topicOptions.map((topic) => (
              <Pressable key={topic} onPress={() => toggleTopic(topic)} style={[styles.chip, topics.has(topic) && styles.chipSelected]}>
                <Text style={[styles.chipText, topics.has(topic) && styles.chipTextSelected]}>{topic}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.onboardingBottom}>
            <Text style={styles.selectionHint}>{topics.size === 0 ? 'Choose at least one topic to continue.' : `${topics.size} topic${topics.size === 1 ? '' : 's'} selected`}</Text>
            <PrimaryButton label="Continue" onPress={next} disabled={topics.size === 0} />
          </View>
        </OnboardingFrame>
      );
    }

    if (step === 4) {
      return (
        <OnboardingFrame step={step} onBack={back} title="Where should we look?" subtitle="Distance is a preference, never a measure of how much you belong.">
          <View style={styles.optionStack}>
            <ChoiceRow label="Match anywhere" detail="A wider, quieter pool" selected={regionMode === 'anywhere'} onPress={() => setRegionMode('anywhere')} />
            <ChoiceRow label="Match near me" detail="People in a similar time zone" selected={regionMode === 'near'} onPress={() => setRegionMode('near')} />
            <ChoiceRow label="Choose a region" detail="You decide where to look" selected={regionMode === 'specific'} onPress={() => setRegionMode('specific')} />
          </View>
          {regionMode === 'specific' && (
            <View style={styles.inlineFields}>
              <Field label="Region" value={region} onChangeText={setRegion} />
            </View>
          )}
          <View style={styles.inlineFields}>
            <Field label="Language" value={language} onChangeText={setLanguage} />
          </View>
          <PrimaryButton label="Continue" onPress={next} />
        </OnboardingFrame>
      );
    }

    if (step === 5) {
      return (
        <OnboardingFrame step={step} onBack={back} title="A clear agreement." subtitle="Here’s how we take care of this space.">
          <View style={styles.safetyList}>
            <SafetyLine number="01" text="Exhale is peer support, not therapy or emergency care." />
            <SafetyLine number="02" text="A conversation only continues when both people want it to." />
            <SafetyLine number="03" text="Sessions disappear unless both people choose to save them." />
            <SafetyLine number="04" text="If safety is a concern, we’ll surface local support and involve a human moderation team." />
          </View>
          <Pressable onPress={() => setSafetyAgreed(!safetyAgreed)} style={[styles.checkRow, safetyAgreed && styles.checkRowActive]}>
            <View style={[styles.checkbox, safetyAgreed && styles.checkboxActive]}>{safetyAgreed && <Text style={styles.checkMark}>✓</Text>}</View>
            <Text style={styles.checkText}>I understand and agree to show up with care.</Text>
          </Pressable>
          <PrimaryButton label="I understand" onPress={next} disabled={!safetyAgreed} />
        </OnboardingFrame>
      );
    }

    return (
      <OnboardingFrame step={step} onBack={back} title="A tiny practice round." subtitle="There’s no perfect way to begin. Try a low-stakes check-in with Lumen.">
        <View style={styles.practiceCard}>
          <View style={styles.botLabel}><View style={styles.botDot} /><Text style={styles.botText}>Lumen · practice guide</Text></View>
          <Text style={styles.practicePrompt}>“What’s one word for the weather inside today?”</Text>
          {practiceSent && <View style={styles.practiceAnswer}><Text style={styles.practiceAnswerText}>{practiceReply}</Text></View>}
        </View>
        {!practiceSent ? (
          <View style={styles.practiceComposer}>
            <TextInput value={practiceReply} onChangeText={setPracticeReply} placeholder="A word or two…" placeholderTextColor={colors.muted} style={styles.practiceInput} />
            <Pressable onPress={() => practiceReply.trim() && setPracticeSent(true)} style={[styles.sendMini, !practiceReply.trim() && styles.sendMiniDisabled]}><Text style={styles.sendMiniText}>↑</Text></Pressable>
          </View>
        ) : (
          <View style={styles.practiceDone}><Text style={styles.practiceDoneText}>That’s enough. You showed up.</Text></View>
        )}
        <View style={styles.onboardingBottom}>
          <PrimaryButton label={practiceSent ? 'Enter Exhale' : 'Skip for now'} onPress={onComplete} quiet={!practiceSent} />
        </View>
      </OnboardingFrame>
    );
  };

  return <SafeAreaView style={styles.app}>{content()}</SafeAreaView>;
}

function OnboardingFrame({ step, title, subtitle, onBack, children }: { step: number; title: string; subtitle: string; onBack: () => void; children: React.ReactNode }) {
  return (
    <View style={styles.onboardingFrame}>
      <View style={styles.onboardingHeader}>
        <Pressable onPress={onBack} hitSlop={12} style={styles.backButton}><Text style={styles.backText}>‹</Text></Pressable>
        <ProgressDots step={step - 1} />
        <View style={styles.headerSpacer} />
      </View>
      <ScrollView contentContainerStyle={styles.onboardingScroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <Text style={styles.onboardingTitle}>{title}</Text>
        <Text style={styles.onboardingSubtitle}>{subtitle}</Text>
        <View style={styles.onboardingContent}>{children}</View>
      </ScrollView>
    </View>
  );
}

function ChoiceRow({ label, detail, selected, onPress }: { label: string; detail?: string; selected: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.choiceRow, selected && styles.choiceRowSelected]}>
      <View><Text style={styles.choiceLabel}>{label}</Text>{detail && <Text style={styles.choiceDetail}>{detail}</Text>}</View>
      <View style={[styles.radio, selected && styles.radioSelected]}>{selected && <View style={styles.radioInner} />}</View>
    </Pressable>
  );
}

function Field({ label, value, onChangeText }: { label: string; value: string; onChangeText: (value: string) => void }) {
  return <View style={styles.field}><Text style={styles.fieldLabel}>{label}</Text><TextInput value={value} onChangeText={onChangeText} style={styles.fieldInput} placeholderTextColor={colors.muted} /></View>;
}

function SafetyLine({ number, text }: { number: string; text: string }) {
  return <View style={styles.safetyLine}><Text style={styles.safetyNumber}>{number}</Text><Text style={styles.safetyText}>{text}</Text></View>;
}

function Home({ onJoin }: { onJoin: () => void }) {
  const [tab, setTab] = useState<Tab>('Today');
  const [mood, setMood] = useState<number | null>(null);
  const [journal, setJournal] = useState(initialJournal);
  const [preferSimilarAge, setPreferSimilarAge] = useState(true);

  const content = () => {
    switch (tab) {
      case 'Journal': return <JournalTab journal={journal} setJournal={setJournal} />;
      case 'Resources': return <ResourcesTab />;
      case 'Settings': return <SettingsTab preferSimilarAge={preferSimilarAge} setPreferSimilarAge={setPreferSimilarAge} />;
      default: return <TodayTab mood={mood} setMood={setMood} onJoin={onJoin} onResources={() => setTab('Resources')} />;
    }
  };

  return (
    <SafeAreaView style={styles.app}>
      <StatusBar style="dark" />
      <View style={styles.homeShell}>{content()}</View>
      <TabBar active={tab} onChange={setTab} />
    </SafeAreaView>
  );
}

function TodayTab({ mood, setMood, onJoin, onResources }: { mood: number | null; setMood: (value: number) => void; onJoin: () => void; onResources: () => void }) {
  return (
    <ScrollView contentContainerStyle={styles.pageContent} showsVerticalScrollIndicator={false}>
      <View style={styles.todayHeader}><View><Text style={styles.dayGreeting}>Saturday, August 30</Text><Text style={styles.pageTitle}>Good afternoon, Maya.</Text></View><AppMark small /></View>
      <View style={styles.sessionCard}>
        <View style={styles.sessionCardTop}><View><Text style={styles.cardEyebrow}>YOUR NEXT CONVERSATION</Text><Text style={styles.sessionTitle}>A calm check-in with Sol</Text></View><View style={styles.timePill}><Text style={styles.timePillText}>Tomorrow</Text></View></View>
        <View style={styles.sessionTiming}><Text style={styles.sessionTime}>7:30 PM</Text><View style={styles.timeLine} /><Text style={styles.sessionLength}>25 minutes</Text></View>
        <Text style={styles.sessionDetail}>A private text conversation, guided gently if you need it.</Text>
        <PrimaryButton label="Enter waiting room" onPress={onJoin} />
      </View>
      <Text style={styles.sectionKicker}>A MOMENT WITH YOURSELF</Text>
      <View style={styles.moodCard}>
        <Text style={styles.moodTitle}>How are you arriving today?</Text>
        <Text style={styles.moodSubtitle}>Just a small tap. No tracking streaks, no pressure.</Text>
        <View style={styles.moodChoices}>
          {moodOptions.map((item, index) => (
            <Pressable key={item.label} onPress={() => setMood(index)} style={styles.moodChoice}>
              <View style={[styles.moodDot, { backgroundColor: item.color }, mood === index && styles.moodDotSelected]}><Text style={styles.moodDotMark}>{item.mark}</Text></View>
              <Text style={[styles.moodLabel, mood === index && styles.moodLabelSelected]}>{item.label}</Text>
            </Pressable>
          ))}
        </View>
        {mood !== null && <Text style={styles.moodAcknowledgement}>Thank you for noticing. That’s enough for now.</Text>}
      </View>
      <BreathingCard />
      <Pressable onPress={onResources} style={styles.supportFooter}><View style={styles.supportIcon}><Text style={styles.supportIconText}>+</Text></View><View style={styles.supportCopy}><Text style={styles.supportTitle}>Need support sooner?</Text><Text style={styles.supportDetail}>Find care and crisis resources for your region.</Text></View><Text style={styles.supportArrow}>›</Text></Pressable>
    </ScrollView>
  );
}

function BreathingCard() {
  const scale = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const animation = Animated.loop(Animated.sequence([
      Animated.timing(scale, { toValue: 1.02, duration: 2000, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 2000, useNativeDriver: true }),
    ]));
    animation.start();
    return () => animation.stop();
  }, [scale]);
  return (
    <View style={styles.breathingCard}>
      <Animated.View style={[styles.breathOrb, { transform: [{ scale }] }]}><Text style={styles.breathOrbText}>pause</Text></Animated.View>
      <View style={styles.breathCopy}><Text style={styles.breathTitle}>One slow breath</Text><Text style={styles.breathDetail}>In for four. Out for six. Let your shoulders lower.</Text></View>
    </View>
  );
}

function JournalTab({ journal, setJournal }: { journal: typeof initialJournal; setJournal: (entries: typeof initialJournal) => void }) {
  const [entry, setEntry] = useState('');
  const moodColors = [colors.canvasDeep, '#E7D7C9', '#D2DDD0', '#AFCCCB', '#97B0C7'];
  const addEntry = () => {
    const trimmed = entry.trim();
    if (!trimmed) return;
    setJournal([{ id: String(Date.now()), date: 'Today', text: trimmed }, ...journal]);
    setEntry('');
  };
  return (
    <ScrollView contentContainerStyle={styles.pageContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
      <Text style={styles.dayGreeting}>A private place</Text><Text style={styles.pageTitle}>Your little record.</Text><Text style={styles.pageIntro}>Nothing here is measured or shared. It’s simply yours to notice.</Text>
      <View style={styles.calendarCard}>
        <View style={styles.calendarHeader}><View><Text style={styles.calendarMonth}>August</Text><Text style={styles.calendarYear}>2026</Text></View><Text style={styles.calendarLegend}>mood, gently held</Text></View>
        <View style={styles.weekLabels}>{['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, index) => <Text key={`${day}-${index}`} style={styles.weekLabel}>{day}</Text>)}</View>
        <View style={styles.heatmap}>{moodWeeks.flatMap((week, weekIndex) => week.map((value, dayIndex) => <View key={`${weekIndex}-${dayIndex}`} style={[styles.heatCell, { backgroundColor: moodColors[value] }]} />))}</View>
        <View style={styles.calendarNote}><View style={styles.calendarNoteDot} /><Text style={styles.calendarNoteText}>Your days can look different. All of them count.</Text></View>
      </View>
      <Text style={styles.sectionKicker}>ONE LINE FOR TODAY</Text>
      <View style={styles.journalComposer}><TextInput value={entry} onChangeText={setEntry} onSubmitEditing={addEntry} placeholder="A thought, a feeling, a small win…" placeholderTextColor={colors.muted} multiline style={styles.journalInput} /><Pressable onPress={addEntry} style={[styles.journalSave, !entry.trim() && styles.journalSaveDisabled]}><Text style={styles.journalSaveText}>Save</Text></Pressable></View>
      <Text style={styles.sectionKicker}>RECENTLY</Text>
      <View style={styles.entryList}>{journal.map((item) => <View key={item.id} style={styles.entryRow}><Text style={styles.entryDate}>{item.date}</Text><Text style={styles.entryText}>{item.text}</Text></View>)}</View>
      <Text style={styles.finiteEnd}>That’s your recent record. No feed, no backlog to catch up on.</Text>
    </ScrollView>
  );
}

function ResourcesTab() {
  return (
    <ScrollView contentContainerStyle={styles.pageContent} showsVerticalScrollIndicator={false}>
      <Text style={styles.dayGreeting}>India · English</Text><Text style={styles.pageTitle}>Support, close at hand.</Text><Text style={styles.pageIntro}>You deserve more care than an app can offer. These are a few places to start.</Text>
      <View style={styles.crisisCard}><Text style={styles.crisisEyebrow}>IF YOU MIGHT HURT YOURSELF</Text><Text style={styles.crisisTitle}>Please reach out now.</Text><Text style={styles.crisisText}>Call 112 for emergency help in India, or contact a person you trust and stay with them if you can.</Text><View style={styles.crisisAction}><Text style={styles.crisisActionText}>112 · Emergency support</Text></View></View>
      <Text style={styles.sectionKicker}>PEOPLE WHO CAN HELP</Text>
      <View style={styles.resourceList}>{resources.map((resource) => <View key={resource.name} style={styles.resourceCard}><Text style={styles.resourceCategory}>{resource.category.toUpperCase()}</Text><Text style={styles.resourceName}>{resource.name}</Text><Text style={styles.resourceInfo}>{resource.info}</Text><Text style={styles.resourceLink}>Open details  ›</Text></View>)}</View>
      <View style={styles.resourceNote}><Text style={styles.resourceNoteText}>This is a demo directory. A live app would verify localized resources and show their latest availability.</Text></View>
    </ScrollView>
  );
}

function SettingsTab({ preferSimilarAge, setPreferSimilarAge }: { preferSimilarAge: boolean; setPreferSimilarAge: (value: boolean) => void }) {
  return (
    <ScrollView contentContainerStyle={styles.pageContent} showsVerticalScrollIndicator={false}>
      <Text style={styles.dayGreeting}>Your space, your terms</Text><Text style={styles.pageTitle}>Settings</Text>
      <Text style={styles.sectionKicker}>MATCHING PREFERENCES</Text>
      <View style={styles.settingGroup}>
        <SettingRow label="Topics" value="Anxiety, work / study stress" />
        <SettingRow label="Match anywhere" value="English" />
        <View style={styles.settingRow}><View><Text style={styles.settingLabel}>Prefer a similar age range</Text><Text style={styles.settingValue}>Optional and private</Text></View><Pressable onPress={() => setPreferSimilarAge(!preferSimilarAge)} style={[styles.switchTrack, preferSimilarAge && styles.switchTrackOn]}><View style={[styles.switchThumb, preferSimilarAge && styles.switchThumbOn]} /></Pressable></View>
      </View>
      <Text style={styles.sectionKicker}>PRIVACY & CARE</Text>
      <View style={styles.settingGroup}>
        <SettingRow label="How your conversations work" value="Ephemeral unless both people save" />
        <SettingRow label="Safety information" value="Crisis resources and moderation" />
        <SettingRow label="Notifications" value="At most one session reminder a day" />
      </View>
      <View style={styles.settingsFooter}><Text style={styles.settingsFooterText}>Exhale never shows likes, followers, read receipts, or online status. There is nothing to keep up with here.</Text></View>
    </ScrollView>
  );
}

function SettingRow({ label, value }: { label: string; value: string }) {
  return <Pressable style={styles.settingRow}><View style={styles.settingCopy}><Text style={styles.settingLabel}>{label}</Text><Text style={styles.settingValue}>{value}</Text></View><Text style={styles.settingChevron}>›</Text></Pressable>;
}

function TabBar({ active, onChange }: { active: Tab; onChange: (tab: Tab) => void }) {
  const tabs: { label: Tab; icon: string }[] = [{ label: 'Today', icon: '○' }, { label: 'Journal', icon: '⌇' }, { label: 'Resources', icon: '+' }, { label: 'Settings', icon: '⋯' }];
  return <View style={styles.tabBar}>{tabs.map((tab) => <Pressable key={tab.label} onPress={() => onChange(tab.label)} style={styles.tabItem}><Text style={[styles.tabIcon, active === tab.label && styles.tabActive]}>{tab.icon}</Text><Text style={[styles.tabLabel, active === tab.label && styles.tabLabelActive]}>{tab.label}</Text></Pressable>)}</View>;
}

function WaitingRoom({ onStart, onCancel }: { onStart: () => void; onCancel: () => void }) {
  return (
    <SafeAreaView style={styles.app}>
      <View style={styles.waitingShell}>
        <View style={styles.sessionTopBar}><SmallAction label="‹ Home" onPress={onCancel} /><Text style={styles.sessionTopTitle}>Waiting room</Text><View style={styles.sessionTopSpacer} /></View>
        <View style={styles.waitingContent}><View style={styles.presenceLine}><View style={styles.presenceDot} /><Text style={styles.presenceText}>Your session is ready</Text></View><View style={styles.personCircle}><Text style={styles.personInitial}>S</Text></View><Text style={styles.waitingTitle}>Sol is here.</Text><Text style={styles.waitingText}>There’s no rush. Take one more breath before you begin your 25-minute check-in.</Text></View>
        <View><View style={styles.waitingPrompt}><Text style={styles.waitingPromptLabel}>TODAY’S GENTLE START</Text><Text style={styles.waitingPromptText}>“What would feel a little lighter if someone simply heard it?”</Text></View><PrimaryButton label="Begin the conversation" onPress={onStart} /><Text style={styles.waitingFinePrint}>Text only · no read receipts · you can end anytime</Text></View>
      </View>
    </SafeAreaView>
  );
}

function Session({ onEnd }: { onEnd: () => void }) {
  const [messages, setMessages] = useState<ChatMessage[]>(starterMessages as ChatMessage[]);
  const [draft, setDraft] = useState('');
  const [historyMine, setHistoryMine] = useState(false);
  const [historySol, setHistorySol] = useState(false);
  const [showResource, setShowResource] = useState(false);
  const send = () => {
    const trimmed = draft.trim();
    if (!trimmed) return;
    setMessages((current) => [...current, { id: String(Date.now()), sender: 'You', text: trimmed, time: 'Now' }]);
    setDraft('');
    if (crisisWords.some((word) => trimmed.toLowerCase().includes(word))) setShowResource(true);
  };
  const toggleHistory = () => {
    const next = !historyMine;
    setHistoryMine(next);
    if (!next) setHistorySol(false);
  };
  return (
    <SafeAreaView style={styles.app}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.chatTopBar}><View><Text style={styles.chatName}>Sol</Text><Text style={styles.chatStatus}>25-minute check-in · no read receipts</Text></View><Pressable onPress={onEnd} style={styles.endButton}><Text style={styles.endButtonText}>End session</Text></Pressable></View>
        <ScrollView style={styles.chatScroll} contentContainerStyle={styles.chatContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <View style={styles.guidedPrompt}><Text style={styles.guidedLabel}>A GENTLE PLACE TO START</Text><Text style={styles.guidedText}>What would feel a little lighter if someone simply heard it?</Text></View>
          <View style={[styles.historyBanner, historyMine && styles.historyBannerActive]}><View style={styles.historyBannerCopy}><Text style={styles.historyTitle}>Save this conversation?</Text><Text style={styles.historyText}>{historyMine && historySol ? 'Both of you saved this conversation.' : historyMine ? 'History saving: waiting on Sol.' : 'It disappears when this session ends unless you both agree.'}</Text></View><Pressable onPress={toggleHistory} style={[styles.historyToggle, historyMine && styles.historyToggleOn]}><View style={[styles.historyToggleThumb, historyMine && styles.historyToggleThumbOn]} /></Pressable></View>
          {historyMine && !historySol && <Pressable onPress={() => setHistorySol(true)} style={styles.demoConsent}><Text style={styles.demoConsentText}>Preview Sol’s mutual consent for this prototype</Text></Pressable>}
          {messages.map((message) => <View key={message.id} style={[styles.messageRow, message.sender === 'You' && styles.messageRowMine]}><View style={[styles.messageBubble, message.sender === 'You' ? styles.messageBubbleMine : styles.messageBubbleSol]}><Text style={[styles.messageText, message.sender === 'You' && styles.messageTextMine]}>{message.text}</Text></View><Text style={[styles.messageTime, message.sender === 'You' && styles.messageTimeMine]}>{message.time}</Text></View>)}
          {showResource && <View style={styles.inSessionCrisis}><Text style={styles.inSessionCrisisTitle}>You deserve support right now.</Text><Text style={styles.inSessionCrisisText}>If you may hurt yourself, call 112 in India or contact someone you trust. This message is also flagged for human follow-up in a live version of Exhale.</Text><Text style={styles.inSessionCrisisLink}>Open support options</Text></View>}
        </ScrollView>
        <View style={styles.composer}><TextInput value={draft} onChangeText={setDraft} onSubmitEditing={send} placeholder="Write what feels true…" placeholderTextColor={colors.muted} style={styles.chatInput} multiline /><Pressable onPress={send} style={[styles.chatSend, !draft.trim() && styles.chatSendDisabled]}><Text style={styles.chatSendText}>↑</Text></Pressable></View>
        <Text style={styles.chatFooter}>Peer support, not therapy · Resources are always one tap away</Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Reflection({ onComplete }: { onComplete: () => void }) {
  const [reflection, setReflection] = useState('');
  const [continueWeekly, setContinueWeekly] = useState(false);
  return (
    <SafeAreaView style={styles.app}>
      <ScrollView contentContainerStyle={styles.reflectionShell} keyboardShouldPersistTaps="handled">
        <View style={styles.reflectionRing}><Text style={styles.reflectionRingText}>✦</Text></View><Text style={styles.reflectionEyebrow}>THE SESSION HAS ENDED</Text><Text style={styles.reflectionTitle}>Before you go—</Text><Text style={styles.reflectionCopy}>What’s one thing you’re taking from this conversation?</Text>
        <View style={styles.reflectionInputWrap}><TextInput value={reflection} onChangeText={setReflection} placeholder="A word, a feeling, a small shift…" placeholderTextColor={colors.muted} multiline style={styles.reflectionInput} /><Text style={styles.privateLabel}>PRIVATE · ONLY FOR YOU</Text></View>
        <Pressable onPress={() => setContinueWeekly(!continueWeekly)} style={[styles.continueCard, continueWeekly && styles.continueCardActive]}><View style={styles.continueCopy}><Text style={styles.continueTitle}>Ask Sol to continue weekly</Text><Text style={styles.continueText}>Only if Sol also wants to. No pressure, no explanation needed.</Text></View><View style={[styles.radio, continueWeekly && styles.radioSelected]}>{continueWeekly && <View style={styles.radioInner} />}</View></Pressable>
        <View style={styles.reflectionBottom}><PrimaryButton label={reflection.trim() ? 'Save reflection & close' : 'Close gently'} onPress={onComplete} /><Text style={styles.reflectionFine}>Your chat has {continueWeekly ? 'been removed. Sol will receive a quiet request.' : 'been removed. Nothing else is waiting for you.'}</Text></View>
      </ScrollView>
    </SafeAreaView>
  );
}

function ClosedSession({ onHome }: { onHome: () => void }) {
  return <SafeAreaView style={styles.app}><View style={styles.closedShell}><AppMark /><Text style={styles.closedTitle}>You showed up.</Text><Text style={styles.closedCopy}>The conversation has ended and the room is closed. Take the rest of your day at your own pace.</Text><PrimaryButton label="Return home" onPress={onHome} quiet /></View></SafeAreaView>;
}

export default function App() {
  const [stage, setStage] = useState<AppStage>('onboarding');
  if (stage === 'onboarding') return <Onboarding onComplete={() => setStage('home')} />;
  if (stage === 'waiting') return <WaitingRoom onCancel={() => setStage('home')} onStart={() => setStage('session')} />;
  if (stage === 'session') return <Session onEnd={() => setStage('reflection')} />;
  if (stage === 'reflection') return <Reflection onComplete={() => setStage('closed')} />;
  if (stage === 'closed') return <ClosedSession onHome={() => setStage('home')} />;
  return <Home onJoin={() => setStage('waiting')} />;
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: colors.canvas }, flex: { flex: 1 },
  welcomeScreen: { flex: 1, paddingHorizontal: 28, paddingVertical: 24, justifyContent: 'space-between' }, welcomeTop: { alignItems: 'center', marginTop: 56 }, mark: { width: 72, height: 72, alignItems: 'center', justifyContent: 'center' }, markSmall: { width: 38, height: 38 }, markRing: { position: 'absolute', width: 66, height: 66, borderRadius: 33, borderColor: colors.sage, borderWidth: 1.5, opacity: 0.65 }, markRingSmall: { width: 34, height: 34, borderRadius: 17 }, markCore: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.primarySoft, borderColor: colors.primary, borderWidth: 1 }, markCoreSmall: { width: 13, height: 13, borderRadius: 7 }, wordmark: { ...type.display, fontSize: 31, color: colors.ink, letterSpacing: -1, marginTop: 10 }, eyebrow: { ...type.body, color: colors.primary, fontSize: 13, letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 14 }, welcomeTitle: { ...type.display, color: colors.ink, fontSize: 43, lineHeight: 51, letterSpacing: -1.3 }, welcomeCopy: { ...type.body, color: colors.inkSoft, fontSize: 17, lineHeight: 26, marginTop: 18, maxWidth: 345 }, welcomeFooter: { gap: 16, marginBottom: 20 }, finePrint: { ...type.body, color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: 'center' },
  button: { minHeight: 54, borderRadius: radius.medium, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20 }, buttonPrimary: { backgroundColor: colors.primary, ...shadow }, buttonQuiet: { backgroundColor: colors.primarySoft }, buttonDisabled: { backgroundColor: colors.line }, buttonPressed: { opacity: 0.8, transform: [{ scale: 0.985 }] }, buttonText: { ...type.body, color: colors.white, fontSize: 16, fontWeight: '600' }, buttonQuietText: { color: colors.primary }, buttonDisabledText: { color: colors.muted },
  onboardingFrame: { flex: 1, paddingHorizontal: 24 }, onboardingHeader: { height: 58, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, backButton: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.white }, backText: { ...type.body, color: colors.ink, fontSize: 34, fontWeight: '300', marginTop: -4 }, headerSpacer: { width: 38 }, progressDots: { flexDirection: 'row', gap: 5 }, progressDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.line }, progressDotActive: { backgroundColor: colors.primary, width: 17 }, onboardingScroll: { paddingTop: 30, paddingBottom: 28, flexGrow: 1 }, onboardingTitle: { ...type.display, color: colors.ink, fontSize: 34, lineHeight: 41, letterSpacing: -0.7 }, onboardingSubtitle: { ...type.body, color: colors.inkSoft, fontSize: 16, lineHeight: 24, marginTop: 12 }, onboardingContent: { marginTop: 32, flex: 1, justifyContent: 'space-between', gap: 22 },
  illustrationCard: { backgroundColor: colors.lavenderSoft, borderRadius: radius.large, padding: 26, alignItems: 'center', gap: 6 }, illustrationIcon: { ...type.display, color: colors.lavender, fontSize: 32 }, illustrationTitle: { ...type.display, color: colors.ink, fontSize: 22, marginTop: 8 }, illustrationCopy: { ...type.body, color: colors.inkSoft, fontSize: 14 }, checkRow: { flexDirection: 'row', padding: 17, borderRadius: radius.medium, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white, alignItems: 'center', gap: 13 }, checkRowActive: { backgroundColor: colors.sageSoft, borderColor: colors.sage }, checkbox: { width: 22, height: 22, borderRadius: 7, borderWidth: 1.5, borderColor: colors.muted, alignItems: 'center', justifyContent: 'center' }, checkboxActive: { backgroundColor: colors.sage, borderColor: colors.sage }, checkMark: { color: colors.white, fontSize: 15, fontWeight: '700' }, checkText: { ...type.body, flex: 1, color: colors.ink, fontSize: 15, lineHeight: 21 },
  optionStack: { gap: 10 }, choiceRow: { backgroundColor: colors.white, borderRadius: radius.medium, borderWidth: 1, borderColor: colors.line, minHeight: 68, paddingHorizontal: 18, paddingVertical: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }, choiceRowSelected: { borderColor: colors.primary, backgroundColor: colors.primarySoft }, choiceLabel: { ...type.body, color: colors.ink, fontSize: 16, fontWeight: '600' }, choiceDetail: { ...type.body, color: colors.inkSoft, fontSize: 13, marginTop: 4 }, radio: { width: 22, height: 22, borderRadius: 11, borderColor: colors.muted, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', flexShrink: 0 }, radioSelected: { borderColor: colors.primary }, radioInner: { width: 12, height: 12, borderRadius: 6, backgroundColor: colors.primary }, chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, chip: { paddingVertical: 11, paddingHorizontal: 15, borderRadius: radius.pill, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.line }, chipSelected: { backgroundColor: colors.sageSoft, borderColor: colors.sage }, chipText: { ...type.body, color: colors.inkSoft, fontSize: 14 }, chipTextSelected: { color: '#526850', fontWeight: '600' }, onboardingBottom: { gap: 13, marginTop: 'auto' }, selectionHint: { ...type.body, color: colors.muted, fontSize: 13, textAlign: 'center' }, inlineFields: { gap: 10 }, field: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.line, borderRadius: radius.medium, paddingHorizontal: 16, paddingTop: 11, paddingBottom: 6 }, fieldLabel: { ...type.body, color: colors.muted, fontSize: 12 }, fieldInput: { ...type.body, color: colors.ink, fontSize: 16, paddingVertical: 4 },
  safetyList: { gap: 18 }, safetyLine: { flexDirection: 'row', gap: 14 }, safetyNumber: { ...type.body, color: colors.primary, fontSize: 12, letterSpacing: 0.6, marginTop: 3 }, safetyText: { ...type.body, color: colors.ink, fontSize: 15, lineHeight: 22, flex: 1 }, practiceCard: { backgroundColor: colors.lavenderSoft, borderRadius: radius.large, padding: 21, gap: 18 }, botLabel: { flexDirection: 'row', gap: 8, alignItems: 'center' }, botDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.lavender }, botText: { ...type.body, color: colors.inkSoft, fontSize: 13 }, practicePrompt: { ...type.display, color: colors.ink, fontSize: 22, lineHeight: 29 }, practiceAnswer: { alignSelf: 'flex-end', backgroundColor: colors.white, padding: 12, borderRadius: 14, borderTopRightRadius: 3 }, practiceAnswerText: { ...type.body, color: colors.ink, fontSize: 15 }, practiceComposer: { flexDirection: 'row', backgroundColor: colors.white, borderColor: colors.line, borderWidth: 1, borderRadius: radius.medium, padding: 6, alignItems: 'center' }, practiceInput: { ...type.body, flex: 1, color: colors.ink, fontSize: 15, paddingHorizontal: 10, paddingVertical: 9 }, sendMini: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' }, sendMiniDisabled: { backgroundColor: colors.line }, sendMiniText: { color: colors.white, fontSize: 22, marginTop: -3 }, practiceDone: { backgroundColor: colors.sageSoft, borderRadius: radius.medium, padding: 17 }, practiceDoneText: { ...type.body, color: '#526850', fontSize: 15, textAlign: 'center' },
  homeShell: { flex: 1 }, pageContent: { paddingHorizontal: 20, paddingTop: 25, paddingBottom: 24, gap: 18 }, todayHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4 }, dayGreeting: { ...type.body, color: colors.primary, fontSize: 13, letterSpacing: 0.5 }, pageTitle: { ...type.display, color: colors.ink, fontSize: 31, lineHeight: 39, letterSpacing: -0.6, marginTop: 5 }, pageIntro: { ...type.body, color: colors.inkSoft, fontSize: 15, lineHeight: 22, marginTop: -8, marginBottom: 4 }, sessionCard: { backgroundColor: colors.primarySoft, borderRadius: radius.large, padding: 21, gap: 18 }, sessionCardTop: { flexDirection: 'row', justifyContent: 'space-between', gap: 10 }, cardEyebrow: { ...type.body, color: colors.primary, fontSize: 11, fontWeight: '700', letterSpacing: 1.05 }, sessionTitle: { ...type.display, color: colors.ink, fontSize: 24, lineHeight: 29, marginTop: 6 }, timePill: { paddingHorizontal: 10, paddingVertical: 6, backgroundColor: colors.white, borderRadius: radius.pill, alignSelf: 'flex-start' }, timePillText: { ...type.body, fontSize: 12, color: colors.primary, fontWeight: '600' }, sessionTiming: { flexDirection: 'row', alignItems: 'center', gap: 9 }, sessionTime: { ...type.body, color: colors.ink, fontSize: 17, fontWeight: '600' }, timeLine: { width: 22, height: 1, backgroundColor: colors.primary, opacity: 0.5 }, sessionLength: { ...type.body, color: colors.inkSoft, fontSize: 14 }, sessionDetail: { ...type.body, color: colors.inkSoft, fontSize: 14, lineHeight: 20, marginTop: -7 }, sectionKicker: { ...type.body, color: colors.muted, fontSize: 11, fontWeight: '700', letterSpacing: 1.05, marginTop: 5 }, moodCard: { backgroundColor: colors.white, borderRadius: radius.large, padding: 20, ...shadow }, moodTitle: { ...type.display, color: colors.ink, fontSize: 21 }, moodSubtitle: { ...type.body, color: colors.inkSoft, fontSize: 14, lineHeight: 20, marginTop: 7 }, moodChoices: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 19 }, moodChoice: { alignItems: 'center', gap: 7, width: 54 }, moodDot: { width: 37, height: 37, borderRadius: 18.5, justifyContent: 'center', alignItems: 'center', borderWidth: 3, borderColor: 'transparent' }, moodDotSelected: { borderColor: colors.ink }, moodDotMark: { color: colors.white, opacity: 0.85, fontSize: 22, lineHeight: 22 }, moodLabel: { ...type.body, color: colors.inkSoft, fontSize: 11 }, moodLabelSelected: { color: colors.ink, fontWeight: '700' }, moodAcknowledgement: { ...type.body, color: '#5C755A', fontSize: 13, textAlign: 'center', marginTop: 17 }, breathingCard: { minHeight: 130, backgroundColor: colors.sageSoft, borderRadius: radius.large, padding: 19, flexDirection: 'row', alignItems: 'center', gap: 18 }, breathOrb: { width: 80, height: 80, borderRadius: 40, backgroundColor: colors.sage, alignItems: 'center', justifyContent: 'center', borderWidth: 8, borderColor: '#D8E5D5' }, breathOrbText: { ...type.display, color: colors.white, fontSize: 15 }, breathCopy: { flex: 1 }, breathTitle: { ...type.display, color: colors.ink, fontSize: 20 }, breathDetail: { ...type.body, color: colors.inkSoft, fontSize: 13, lineHeight: 19, marginTop: 5 }, supportFooter: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.white, borderRadius: radius.medium, padding: 16, marginTop: 1 }, supportIcon: { width: 31, height: 31, borderRadius: 15.5, backgroundColor: colors.coralSoft, alignItems: 'center', justifyContent: 'center' }, supportIconText: { color: colors.coral, fontSize: 20, fontWeight: '400' }, supportCopy: { flex: 1 }, supportTitle: { ...type.body, color: colors.ink, fontSize: 14, fontWeight: '600' }, supportDetail: { ...type.body, color: colors.inkSoft, fontSize: 12, marginTop: 3 }, supportArrow: { color: colors.muted, fontSize: 25 },
  tabBar: { backgroundColor: '#FFFCF9', borderTopColor: colors.line, borderTopWidth: 1, height: 72, paddingHorizontal: 15, paddingTop: 9, flexDirection: 'row', justifyContent: 'space-around' }, tabItem: { alignItems: 'center', gap: 3, minWidth: 57 }, tabIcon: { ...type.body, color: colors.muted, fontSize: 19, lineHeight: 21 }, tabActive: { color: colors.primary, fontWeight: '700' }, tabLabel: { ...type.body, color: colors.muted, fontSize: 10 }, tabLabelActive: { color: colors.primary, fontWeight: '700' },
  calendarCard: { backgroundColor: colors.white, borderRadius: radius.large, padding: 20, ...shadow }, calendarHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 19 }, calendarMonth: { ...type.display, color: colors.ink, fontSize: 23 }, calendarYear: { ...type.body, color: colors.muted, fontSize: 13, marginTop: 2 }, calendarLegend: { ...type.body, color: colors.muted, fontSize: 11 }, weekLabels: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }, weekLabel: { ...type.body, color: colors.muted, fontSize: 10, width: 30, textAlign: 'center' }, heatmap: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 8 }, heatCell: { width: 30, height: 26, borderRadius: 7 }, calendarNote: { flexDirection: 'row', alignItems: 'center', gap: 7, borderTopColor: colors.line, borderTopWidth: 1, marginTop: 17, paddingTop: 14 }, calendarNoteDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.sage }, calendarNoteText: { ...type.body, color: colors.inkSoft, fontSize: 12, flex: 1 }, journalComposer: { backgroundColor: colors.white, borderRadius: radius.medium, padding: 13, borderWidth: 1, borderColor: colors.line }, journalInput: { ...type.display, color: colors.ink, fontSize: 17, lineHeight: 23, minHeight: 63, textAlignVertical: 'top' }, journalSave: { alignSelf: 'flex-end', backgroundColor: colors.primarySoft, paddingVertical: 8, paddingHorizontal: 14, borderRadius: radius.pill }, journalSaveDisabled: { opacity: 0.5 }, journalSaveText: { ...type.body, color: colors.primary, fontSize: 13, fontWeight: '700' }, entryList: { backgroundColor: colors.white, borderRadius: radius.medium, overflow: 'hidden' }, entryRow: { padding: 16, borderBottomWidth: 1, borderBottomColor: colors.line, gap: 6 }, entryDate: { ...type.body, color: colors.primary, fontSize: 12, fontWeight: '700' }, entryText: { ...type.display, color: colors.ink, fontSize: 17, lineHeight: 23 }, finiteEnd: { ...type.body, color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: 'center', paddingHorizontal: 20 },
  crisisCard: { backgroundColor: colors.coralSoft, borderRadius: radius.large, padding: 21, gap: 9 }, crisisEyebrow: { ...type.body, color: '#A65E53', fontSize: 11, letterSpacing: 0.9, fontWeight: '700' }, crisisTitle: { ...type.display, color: colors.ink, fontSize: 25 }, crisisText: { ...type.body, color: colors.inkSoft, fontSize: 14, lineHeight: 20 }, crisisAction: { backgroundColor: '#F3D2CB', paddingVertical: 12, paddingHorizontal: 13, borderRadius: radius.small, marginTop: 4 }, crisisActionText: { ...type.body, color: '#944D43', fontSize: 14, fontWeight: '700' }, resourceList: { gap: 11 }, resourceCard: { backgroundColor: colors.white, borderRadius: radius.medium, padding: 18, ...shadow }, resourceCategory: { ...type.body, color: colors.primary, fontSize: 10, letterSpacing: 0.8, fontWeight: '700' }, resourceName: { ...type.display, color: colors.ink, fontSize: 19, marginTop: 6 }, resourceInfo: { ...type.body, color: colors.inkSoft, fontSize: 14, marginTop: 6 }, resourceLink: { ...type.body, color: colors.primary, fontSize: 13, marginTop: 16, fontWeight: '700' }, resourceNote: { backgroundColor: colors.canvasDeep, borderRadius: radius.small, padding: 15 }, resourceNoteText: { ...type.body, color: colors.inkSoft, fontSize: 12, lineHeight: 18 },
  settingGroup: { backgroundColor: colors.white, borderRadius: radius.medium, overflow: 'hidden' }, settingRow: { minHeight: 73, paddingHorizontal: 17, paddingVertical: 13, borderBottomColor: colors.line, borderBottomWidth: 1, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 10 }, settingCopy: { flex: 1 }, settingLabel: { ...type.body, color: colors.ink, fontSize: 15, fontWeight: '600' }, settingValue: { ...type.body, color: colors.inkSoft, fontSize: 12, marginTop: 5 }, settingChevron: { ...type.body, color: colors.muted, fontSize: 24 }, switchTrack: { width: 44, height: 26, borderRadius: 13, backgroundColor: colors.line, padding: 3, justifyContent: 'center' }, switchTrackOn: { backgroundColor: colors.sage }, switchThumb: { width: 20, height: 20, borderRadius: 10, backgroundColor: colors.white }, switchThumbOn: { alignSelf: 'flex-end' }, settingsFooter: { backgroundColor: colors.lavenderSoft, borderRadius: radius.medium, padding: 18, marginTop: 5 }, settingsFooterText: { ...type.body, color: colors.inkSoft, fontSize: 13, lineHeight: 20 },
  smallAction: { minWidth: 64, paddingVertical: 8, paddingHorizontal: 5 }, smallActionText: { ...type.body, color: colors.primary, fontSize: 14, fontWeight: '600' }, waitingShell: { flex: 1, padding: 20, justifyContent: 'space-between' }, sessionTopBar: { height: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, sessionTopTitle: { ...type.body, color: colors.inkSoft, fontSize: 13 }, sessionTopSpacer: { width: 64 }, waitingContent: { alignItems: 'center', paddingHorizontal: 16, marginTop: -20 }, presenceLine: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: colors.sageSoft, paddingHorizontal: 12, paddingVertical: 7, borderRadius: radius.pill, marginBottom: 35 }, presenceDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.sage }, presenceText: { ...type.body, color: '#5C755A', fontSize: 12, fontWeight: '600' }, personCircle: { width: 108, height: 108, borderRadius: 54, backgroundColor: colors.lavenderSoft, borderWidth: 7, borderColor: colors.white, alignItems: 'center', justifyContent: 'center', ...shadow }, personInitial: { ...type.display, color: colors.lavender, fontSize: 43 }, waitingTitle: { ...type.display, color: colors.ink, fontSize: 37, marginTop: 25 }, waitingText: { ...type.body, color: colors.inkSoft, fontSize: 16, lineHeight: 24, textAlign: 'center', marginTop: 12 }, waitingPrompt: { backgroundColor: colors.white, borderRadius: radius.medium, padding: 17, marginBottom: 13 }, waitingPromptLabel: { ...type.body, color: colors.primary, fontSize: 10, letterSpacing: 0.9, fontWeight: '700' }, waitingPromptText: { ...type.display, color: colors.ink, fontSize: 17, lineHeight: 23, marginTop: 7 }, waitingFinePrint: { ...type.body, color: colors.muted, fontSize: 11, textAlign: 'center', marginTop: 13 },
  chatTopBar: { minHeight: 68, paddingHorizontal: 20, paddingVertical: 12, backgroundColor: '#FFFCF9', borderBottomWidth: 1, borderBottomColor: colors.line, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, chatName: { ...type.display, color: colors.ink, fontSize: 21 }, chatStatus: { ...type.body, color: colors.muted, fontSize: 11, marginTop: 2 }, endButton: { backgroundColor: colors.coralSoft, borderRadius: radius.pill, paddingVertical: 8, paddingHorizontal: 12 }, endButtonText: { ...type.body, color: '#9B5B50', fontSize: 12, fontWeight: '700' }, chatScroll: { flex: 1 }, chatContent: { padding: 16, gap: 13 }, guidedPrompt: { backgroundColor: colors.lavenderSoft, borderRadius: radius.medium, padding: 16 }, guidedLabel: { ...type.body, color: colors.lavender, fontSize: 10, letterSpacing: 0.9, fontWeight: '700' }, guidedText: { ...type.display, color: colors.ink, fontSize: 18, lineHeight: 24, marginTop: 5 }, historyBanner: { backgroundColor: colors.white, borderRadius: radius.medium, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: colors.line }, historyBannerActive: { borderColor: colors.sage, backgroundColor: colors.sageSoft }, historyBannerCopy: { flex: 1 }, historyTitle: { ...type.body, color: colors.ink, fontSize: 14, fontWeight: '700' }, historyText: { ...type.body, color: colors.inkSoft, fontSize: 12, lineHeight: 17, marginTop: 3 }, historyToggle: { width: 40, height: 24, borderRadius: 12, backgroundColor: colors.line, padding: 3, justifyContent: 'center' }, historyToggleOn: { backgroundColor: colors.sage }, historyToggleThumb: { width: 18, height: 18, borderRadius: 9, backgroundColor: colors.white }, historyToggleThumbOn: { alignSelf: 'flex-end' }, demoConsent: { alignSelf: 'center', paddingVertical: 4 }, demoConsentText: { ...type.body, color: colors.primary, fontSize: 11, textDecorationLine: 'underline' }, messageRow: { alignSelf: 'flex-start', maxWidth: '84%', gap: 4, marginTop: 1 }, messageRowMine: { alignSelf: 'flex-end', alignItems: 'flex-end' }, messageBubble: { paddingHorizontal: 14, paddingVertical: 11, borderRadius: 18 }, messageBubbleSol: { backgroundColor: colors.white, borderTopLeftRadius: 4 }, messageBubbleMine: { backgroundColor: colors.primary, borderTopRightRadius: 4 }, messageText: { ...type.body, color: colors.ink, fontSize: 15, lineHeight: 21 }, messageTextMine: { color: colors.white }, messageTime: { ...type.body, color: colors.muted, fontSize: 10, marginLeft: 5 }, messageTimeMine: { marginLeft: 0, marginRight: 5 }, inSessionCrisis: { backgroundColor: colors.coralSoft, borderRadius: radius.medium, padding: 17, marginTop: 8 }, inSessionCrisisTitle: { ...type.display, color: colors.ink, fontSize: 20 }, inSessionCrisisText: { ...type.body, color: colors.inkSoft, fontSize: 13, lineHeight: 19, marginTop: 7 }, inSessionCrisisLink: { ...type.body, color: '#965348', fontSize: 13, fontWeight: '700', marginTop: 12 }, composer: { backgroundColor: '#FFFCF9', borderTopColor: colors.line, borderTopWidth: 1, padding: 10, flexDirection: 'row', alignItems: 'flex-end', gap: 8 }, chatInput: { ...type.body, flex: 1, maxHeight: 96, minHeight: 40, backgroundColor: colors.white, borderColor: colors.line, borderWidth: 1, borderRadius: 20, color: colors.ink, paddingHorizontal: 15, paddingTop: 10, paddingBottom: 9, fontSize: 15 }, chatSend: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center' }, chatSendDisabled: { backgroundColor: colors.line }, chatSendText: { color: colors.white, fontSize: 22, marginTop: -4 }, chatFooter: { ...type.body, paddingHorizontal: 16, paddingBottom: 8, color: colors.muted, backgroundColor: '#FFFCF9', textAlign: 'center', fontSize: 10 },
  reflectionShell: { padding: 25, paddingTop: 58, paddingBottom: 28, flexGrow: 1 }, reflectionRing: { width: 57, height: 57, borderRadius: 29, backgroundColor: colors.sageSoft, justifyContent: 'center', alignItems: 'center', alignSelf: 'center' }, reflectionRingText: { color: colors.sage, fontSize: 23 }, reflectionEyebrow: { ...type.body, color: colors.primary, fontSize: 11, letterSpacing: 1, fontWeight: '700', textAlign: 'center', marginTop: 22 }, reflectionTitle: { ...type.display, color: colors.ink, fontSize: 35, textAlign: 'center', marginTop: 7 }, reflectionCopy: { ...type.body, color: colors.inkSoft, fontSize: 16, textAlign: 'center', lineHeight: 24, marginTop: 9, paddingHorizontal: 10 }, reflectionInputWrap: { backgroundColor: colors.white, borderRadius: radius.large, padding: 18, marginTop: 29, borderWidth: 1, borderColor: colors.line }, reflectionInput: { ...type.display, color: colors.ink, fontSize: 19, lineHeight: 25, minHeight: 82, textAlignVertical: 'top' }, privateLabel: { ...type.body, color: colors.muted, fontSize: 10, fontWeight: '700', letterSpacing: 0.8, marginTop: 8 }, continueCard: { flexDirection: 'row', gap: 12, backgroundColor: colors.lavenderSoft, borderRadius: radius.medium, padding: 17, marginTop: 16, alignItems: 'center', borderWidth: 1, borderColor: 'transparent' }, continueCardActive: { borderColor: colors.lavender }, continueCopy: { flex: 1 }, continueTitle: { ...type.body, color: colors.ink, fontSize: 15, fontWeight: '700' }, continueText: { ...type.body, color: colors.inkSoft, fontSize: 12, lineHeight: 17, marginTop: 5 }, reflectionBottom: { marginTop: 'auto', paddingTop: 26, gap: 13 }, reflectionFine: { ...type.body, color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: 'center' },
  closedShell: { flex: 1, padding: 28, alignItems: 'center', justifyContent: 'center', gap: 16 }, closedTitle: { ...type.display, color: colors.ink, fontSize: 37, marginTop: 8 }, closedCopy: { ...type.body, color: colors.inkSoft, fontSize: 16, lineHeight: 24, textAlign: 'center', marginBottom: 18, maxWidth: 340 },
});
