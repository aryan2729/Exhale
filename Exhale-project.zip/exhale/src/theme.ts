import { Platform } from 'react-native';

export const colors = {
  canvas: '#FAF8F5',
  canvasDeep: '#F3EFEA',
  surface: '#FFFFFF',
  ink: '#343432',
  inkSoft: '#6D6B67',
  muted: '#99958E',
  line: '#E8E2DB',
  primary: '#647F9D',
  primarySoft: '#E8EEF4',
  sage: '#9AAD97',
  sageSoft: '#E9F0E6',
  lavender: '#AAA0BB',
  lavenderSoft: '#F0EDF5',
  sand: '#E9DCCB',
  coral: '#C97D70',
  coralSoft: '#F9E8E3',
  white: '#FFFFFF',
  scrim: 'rgba(52, 52, 50, 0.25)',
};

export const radius = {
  small: 14,
  medium: 18,
  large: 24,
  pill: 999,
};

export const shadow = Platform.select({
  ios: {
    shadowColor: '#6B6259',
    shadowOpacity: 0.08,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
  },
  android: { elevation: 2 },
  default: {},
});

export const type = {
  display: { fontFamily: Platform.select({ ios: 'Georgia', android: 'serif', default: 'Georgia' }) },
  body: { fontFamily: Platform.select({ ios: 'Avenir Next', android: 'sans-serif', default: 'sans-serif' }) },
};
