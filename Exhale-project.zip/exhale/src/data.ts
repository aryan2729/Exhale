export const topicOptions = [
  'Anxiety',
  'Low mood',
  'Sleep',
  'Work / study stress',
  'Grief',
  'Loneliness',
  'Other',
];

export const ageBrackets = ['18–24', '25–34', '35–44', '45–54', '55+'];

export const starterMessages = [
  { id: '1', sender: 'Sol', text: 'Hi Maya. I’m glad we made this time for a pause.', time: '7:31 PM' },
  { id: '2', sender: 'You', text: 'Me too. It’s been a full week.', time: '7:32 PM' },
  { id: '3', sender: 'Sol', text: 'Would it feel okay to start with one small thing that has been sitting with you?', time: '7:33 PM' },
];

export const initialJournal = [
  { id: '1', date: 'Today', text: 'A slower morning than usual. That felt good.' },
  { id: '2', date: 'Thursday', text: 'Asked for help before it got too heavy.' },
  { id: '3', date: 'Tuesday', text: 'The evening walk made room in my head.' },
];

export const moodWeeks = [
  [0, 1, 2, 0, 3, 2, 1],
  [1, 1, 3, 2, 2, 4, 2],
  [0, 2, 2, 1, 3, 3, 4],
  [2, 3, 4, 2, 1, 2, 3],
  [1, 0, 2, 3, 3, 2, 4],
];

export const resources = [
  { category: 'Immediate support', name: 'KIRAN Mental Health Helpline', info: '1800-599-0019 · 24 / 7' },
  { category: 'Emergency', name: 'National emergency number', info: '112 · Immediate help' },
  { category: 'Finding care', name: 'AASRA Suicide Prevention', info: '91-22-27546669 · aasra.info' },
];
